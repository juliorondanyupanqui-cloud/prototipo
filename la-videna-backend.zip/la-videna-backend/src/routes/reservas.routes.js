import { Router } from 'express';
import {
    listarCanchas,
    listarReservas,
    crearReserva,
    eliminarReserva
} from '../controllers/reservas.controller.js';

const router = Router();

router.get('/canchas', listarCanchas);
router.get('/reservas', listarReservas);
router.post('/reservas', crearReserva);
router.delete('/reservas/:id', eliminarReserva);

export default router;

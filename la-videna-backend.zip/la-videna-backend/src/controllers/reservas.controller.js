import { CANCHAS, verificarConflictoHorario } from '../utils/motorBackend.js';

let reservasDB = [];

export const listarCanchas = (req, res) => {
    res.json({ success: true, data: Object.values(CANCHAS) });
};

export const listarReservas = (req, res) => {
    res.json({ success: true, data: reservasDB });
};

export const crearReserva = (req, res) => {
    const nuevaReserva = req.body;
    const d = nuevaReserva?.detallesReserva;

    if (!d || !d.instalacionId || !d.fechaProgramada || !d.horaInicio) {
        return res.status(400).json({
            success: false,
            error: 'VALIDATION_ERROR',
            message: 'Datos incompletos para procesar la reserva.'
        });
    }

    const conflicto = verificarConflictoHorario(
        d.instalacionId,
        d.fechaProgramada,
        d.horaInicio,
        d.duracionHoras,
        reservasDB
    );

    if (conflicto) {
        return res.status(409).json({
            success: false,
            error: 'SCHEDULE_CONFLICT',
            message: `Cruce de horario con la reserva ${conflicto.codigo} (${conflicto.detallesReserva.horaInicio} - ${conflicto.detallesReserva.horaFin}).`
        });
    }

    reservasDB.push(nuevaReserva);
    res.status(201).json({
        success: true,
        message: 'Reserva registrada exitosamente.',
        data: nuevaReserva
    });
};

export const eliminarReserva = (req, res) => {
    const { id } = req.params;
    reservasDB = reservasDB.filter((r) => String(r.id) !== String(id));
    res.json({ success: true, message: 'Reserva eliminada correctamente.' });
};
